package WebServlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.UsuarioDao;

@WebServlet("/loginusuario")
public class LoginUsuarioServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String email = request.getParameter("email");
		String senha = request.getParameter("senha");

		UsuarioDao dao = new UsuarioDao();

		boolean logado = dao.efetuarLogin(email, senha);

		if (logado == true) {

			request.getRequestDispatcher("HomePage.jsp").forward(request, response);
			System.out.println("logado ou nao");

		}else if(logado == false){
			request.getRequestDispatcher("CadastrarUsuario.jsp").forward(request, response);
		}
			
	}
}