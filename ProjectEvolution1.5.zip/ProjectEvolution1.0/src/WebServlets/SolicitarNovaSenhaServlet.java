
package WebServlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.UsuarioDao;
	@WebServlet("/index")
	public class SolicitarNovaSenhaServlet extends HttpServlet {

		protected void doPost(HttpServletRequest request, HttpServletResponse response)
				throws ServletException, IOException {

			String email = request.getParameter("email");

			UsuarioDao dao = new UsuarioDao();

			boolean reset = dao.solicitarnovaSenha(email);

			if (reset == true) {
				
				request.getRequestDispatcher("NovaSenha.jsp").forward(request, response);
				System.out.println("logado ou nao");

			}else if(reset == false){
				request.getRequestDispatcher("CadastrarUsuario.jsp").forward(request, response);
			}
				

		}
	}

