package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import Entidades.Usuario;
import Util.ConnectionFactory;

public class UsuarioDao {

	private Connection connection;

	public UsuarioDao() {

		try {
			this.connection = new ConnectionFactory().getConnection();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

	public void salvar(Usuario usuario) {

		String sql = "INSERT INTO usuarios (nome, senha, email, confsenha, cpf) VALUES (?,?,?,?,?)";
		PreparedStatement stmt;

		try {
			stmt = connection.prepareStatement(sql);

			stmt.setString(1, usuario.getNome());
			stmt.setString(2, usuario.getSenha());
			stmt.setString(3, usuario.getEmail());
			stmt.setString(4, usuario.getConfsenha());
			stmt.setString(5, usuario.getCpf());

			stmt.execute();
			connection.close();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}

	}

	public boolean efetuarLogin(String email, String senha) {

		try {

			PreparedStatement stmt = this.connection
					.prepareStatement("SELECT * FROM usuarios WHERE email = ?  AND senha = ?");

			stmt.setString(1, email);
			stmt.setString(2, senha);

			ResultSet rs = stmt.executeQuery();

			if (rs.next()) {

				return true;
			}

			rs.close();
			stmt.close();
			connection.close();

			return false;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}

	}

	public boolean solicitarnovaSenha(String email) {

		try {

			PreparedStatement stmt = this.connection.prepareStatement("SELECT email FROM usuarios WHERE email = ? ");

			stmt.setString(1, email);

			ResultSet rs = stmt.executeQuery();

			if (rs.next()) {

				return true;
			}

			rs.close();
			stmt.close();
			connection.close();

			return false;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

	public void novasenha(String senha, String confsenha) {
		String sql = "UPDATE usuarios SET senha = ?, confsenha = ? WHERE cpf = ?";
		PreparedStatement stmt;
		
	}
}